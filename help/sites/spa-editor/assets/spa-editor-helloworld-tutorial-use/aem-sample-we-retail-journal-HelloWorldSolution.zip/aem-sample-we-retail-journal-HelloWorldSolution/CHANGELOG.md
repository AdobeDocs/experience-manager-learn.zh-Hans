### *1.2.0* - 5 April 2019

* **NEW FEATURE** Template Editor
  * Give access to the list of Allowed Components from the ResponsiveGrid component

### *1.1.8* - 20 December 2018

Downgrade com.fasterxml.jackson dependencies to match the AEM 6.4 dependencies for SP3

### *1.1.6* - 13 December 2018

Public release, which provides:
* Added dynamic routing in Angular
* Introduced language branch in React and Angular

### *1.1.4* - 5 December 2018

Public release, which provides:
 * Inline editing of Text component breaks SPA state update
 * Improve documentation
 * Update nodemon, nodejs, npm, com.fasterxml.jackson.core and core.wcm.components dependencies
