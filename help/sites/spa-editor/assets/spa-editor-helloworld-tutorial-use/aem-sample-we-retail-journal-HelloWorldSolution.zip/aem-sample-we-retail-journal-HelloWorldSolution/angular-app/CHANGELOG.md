### *1.1.4* - 5 December 2018

Public release, which provides:
 * Inline editing of Text component breaks SPA state update
 * Update nodejs and npm dependencies