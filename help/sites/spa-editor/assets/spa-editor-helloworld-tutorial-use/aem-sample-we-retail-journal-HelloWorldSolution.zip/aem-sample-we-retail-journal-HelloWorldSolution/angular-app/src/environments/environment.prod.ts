export const environment = {
  production: true,
  API_HOST: "",
  APP_ROOT_PATH: "/content/we-retail-journal/angular",
  CONTEXT_PATH: "" // configuration style: contextpath/
};
