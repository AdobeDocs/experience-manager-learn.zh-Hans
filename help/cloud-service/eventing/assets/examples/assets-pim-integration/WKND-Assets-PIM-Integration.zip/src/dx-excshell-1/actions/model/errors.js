/* eslint-disable max-classes-per-file */
class InvalidEventPayload extends Error {
  constructor(message) {
    super(message);
    Error.captureStackTrace(this, this.constructor);
  }
}

class AEMConnectionError extends Error {
  constructor(message) {
    super(message);
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = {
  InvalidEventPayload,
  AEMConnectionError,
};
