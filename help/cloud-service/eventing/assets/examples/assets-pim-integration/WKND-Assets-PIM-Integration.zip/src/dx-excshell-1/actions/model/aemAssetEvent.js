/* eslint-disable prefer-destructuring */
/* eslint-disable max-len */
const { InvalidEventPayload } = require('./errors');

/**
 * AEM Asset Event class, used to parse AEM Asset Event data and provide helper methods to access the data.
 *
 *
 * @class AEMAssetEvent
 * @param {Object} params - arams object via Adobe I/O Runtime Action
 *
 *
 */
class AEMAssetEvent {
  constructor(params) {
    // Validate the params, make sure we have the required properties
    if (
      params === undefined
      && params.data === undefined
      && params.data.assetId === undefined
    ) {
      throw new InvalidEventPayload('Invalid AEM Asset Event payload');
    }

    this.source = params.source;
    this.data = params.data;
    this.id = params.id;
    this.recipient_client_id = params.recipient_client_id;
    this.time = params.time;
    this.type = params.type;
    this.LOG_LEVEL = params.LOG_LEVEL;
    this.datacontenttype = params.datacontenttype;
    this.event_id = params.event_id;
    this.specversion = params.specversion;

    // Split the type into parts
    const typeParts = this.type.split('.');
    if (typeParts.length === 4) {
      this.Provider = `${typeParts[0]}.${typeParts[1]}`;
      this.ContentType = typeParts[2];
      this.EventName = typeParts[3];
    }
  }

  getAEMHost() {
    let aemHost;
    // Parse the source value
    const sourceParts = this.source.split(':');
    if (sourceParts.length === 2) {
      aemHost = sourceParts[1].split('@')[0];
    }
    return aemHost;
  }

  getRepositoryMetadata() {
    let repositoryMetadata;
    if (this.data && this.data.repositoryMetadata) {
      repositoryMetadata = this.data.repositoryMetadata;
    }
    return repositoryMetadata;
  }

  getAssetId() {
    let assetId;
    if (this.data && this.data.assetId) {
      assetId = this.data.assetId;
    }
    return assetId;
  }

  getAssetPath() {
    let assetPath;
    if (
      this.data
      && this.data.repositoryMetadata
      && this.data.repositoryMetadata['repo:path']
    ) {
      assetPath = this.data.repositoryMetadata['repo:path'];
    }
    return assetPath;
  }

  getAssetName() {
    let assetName;
    if (
      this.data
      && this.data.repositoryMetadata
      && this.data.repositoryMetadata['repo:name']
    ) {
      assetName = this.data.repositoryMetadata['repo:name'];
    }
    return assetName;
  }

  getSource() {
    return this.source;
  }

  getData() {
    return this.data;
  }

  getId() {
    return this.id;
  }

  getRecipientClientId() {
    return this.recipient_client_id;
  }

  getTime() {
    return this.time;
  }

  getType() {
    return this.type;
  }

  getLogLevel() {
    return this.LOG_LEVEL;
  }

  getDataContentType() {
    return this.datacontenttype;
  }

  getEventId() {
    return this.event_id;
  }

  getSpecVersion() {
    return this.specversion;
  }
}

module.exports = AEMAssetEvent;
