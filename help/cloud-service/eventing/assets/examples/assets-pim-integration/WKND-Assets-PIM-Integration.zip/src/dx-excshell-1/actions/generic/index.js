/* eslint-disable max-len */
/*
 * <license header>
 */

const { Core } = require('@adobe/aio-sdk');
const {
  errorResponse,
  stringParameters,
  checkMissingRequestInputs,
} = require('../utils');
const { InvalidEventPayload } = require('../model/errors');
const AEMAssetEvent = require('../model/aemAssetEvent');
const mockPIMAPI = require('./mockPIMCommunicator');
const { updateAEMAssetMetadata } = require('./aemCommunicator');

/**
 *  This `aemassets-pim-integration` action receives an AEM Asset Event from Adobe I/O Events.
 *
 * - First it creates an AEM Asset Event object from the request parameters. The class `AEMAssetEvent` is defined in `model/aemAssetEvent.js`, and it provides helper methods to extract the asset details from the event.
 * - Then using following modules it performs the following tasks:
 *    - `mockPIMCommunicator.js` - to call the mock PIM API to get the product data such as SKU, Supplier, etc.
 *    - `aemCommunicator.js` - to update the AEM Asset metadata with the PIM data.
 *
 * @param {*} params
 * @returns {object} The response object
 */
async function main(params) {
  // create a Logger
  const logger = Core.Logger('main', { level: params.LOG_LEVEL || 'info' });

  try {
    // 'info' is the default level if not set
    logger.info('Calling the main action');

    // log parameters, only if params.LOG_LEVEL === 'debug'
    logger.debug(stringParameters(params));

    // check for missing request input parameters and headers
    const requiredParams = ['id'];
    const requiredHeaders = [];
    const errorMessage = checkMissingRequestInputs(
      params,
      requiredParams,
      requiredHeaders,
    );
    if (errorMessage) {
      // return and log client errors
      return errorResponse(400, errorMessage, logger);
    }

    let responseMsg;

    // handle the challenge probe request, they are sent by I/O to verify the action is valid
    if (params.challenge) {
      logger.info('Challenge probe request detected');
      responseMsg = JSON.stringify({ challenge: params.challenge });
    } else {
      logger.info('AEM Asset Event request received');

      // create AEM Asset Event object from request parameters
      const aemAssetEvent = new AEMAssetEvent(params);

      // Call mock PIM API to get the product data such as SKU, Supplier, etc.
      const mockPIMData = await mockPIMAPI.getPIMData(
        aemAssetEvent.getAssetName(),
      );
      logger.info('Mock PIM API response', mockPIMData);

      // Update PIM received data in AEM as Asset metadata
      const aemUpdateStatus = await updateAEMAssetMetadata(
        mockPIMData,
        aemAssetEvent,
        params,
      );
      logger.info('AEM Asset metadata update status', aemUpdateStatus);

      if (aemUpdateStatus) {
        // create response message
        responseMsg = JSON.stringify({
          message:
            'AEM Asset Event processed successfully, updated the asset metadata with PIM data.',
          assetdata: {
            assetName: aemAssetEvent.getAssetName(),
            assetPath: aemAssetEvent.getAssetPath(),
            assetId: aemAssetEvent.getAssetId(),
            aemHost: aemAssetEvent.getAEMHost(),
            pimdata: mockPIMData,
          },
        });
      } else {
        responseMsg = JSON.stringify({
          message:
            'Failed AEM Asset Event processing, failed to update the asset metadata in AEM with PIM data.',
          assetdata: {
            assetName: aemAssetEvent.getAssetName(),
            assetPath: aemAssetEvent.getAssetPath(),
            assetId: aemAssetEvent.getAssetId(),
            aemHost: aemAssetEvent.getAEMHost(),
            pimdata: mockPIMData,
          },
        });
      }

      // response object
      const response = {
        statusCode: 200,
        body: responseMsg,
      };
      logger.info('Adobe I/O Runtime action response', response);

      // Return the response to the caller
      return response;
    }
  } catch (error) {
    // AEMAssetEvent constructor throws InvalidEventPayload
    if (error instanceof InvalidEventPayload) {
      logger.error(error);
      return errorResponse(400, error.message, logger);
    }

    // log any server errors
    logger.error(error);
    // return with 500
    return errorResponse(500, 'server error', logger);
  }
}

exports.main = main;
