package com.aemformscs.documentservices;

public class ExecuteAssemblerService {

	public static void main(String[] args) {
		String assembleURL = "https://author-p24107-e104692.adobeaemcloud.com/adobe/forms/assembler/ddx/invoke";
		new AssemblePDFFiles().assemblePDF(assembleURL);
		

	}

}
